<?php
// common header included into teacher pages to match student UI
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= isset($page_title) ? htmlspecialchars($page_title) : 'Quizizz' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('../backgroundquizteacher.png') center/cover no-repeat fixed;
            background-color: #2a0055;
            min-height: 100vh;
            font-family: Poppins, sans-serif;
            color: #fff;
        }
        .app-card {
            background: rgba(60,0,110,0.75);
            border-radius: 18px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.4);
            color: #fff;
        }
        .btn-primary-custom {
            background-color:#FFD43B;
            color:#2a0055;
            font-weight:700;
            border-radius:12px;
            padding:10px 18px;
        }
        .nav-brand {
            display:flex; align-items:center; gap:12px;
        }
        .navbar-logo { height:36px; width:auto; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg" style="background:rgba(255,255,255,0.06);backdrop-filter:blur(6px);padding:10px 20px;">
  <div class="container-fluid">
    <div class="nav-brand">
      <img src="../logoremovedbg.png" class="navbar-logo" alt="logo">
      <strong><?= htmlspecialchars(current_user()['fullname'] ?? 'Teacher') ?></strong>
    </div>
    <div class="collapse navbar-collapse justify-content-end">
      <a href="../dashboard.php" class="btn btn-sm btn-outline-light me-2">Dashboard</a>
      <a href="../logout.php" class="btn btn-sm btn-warning">Logout</a>
    </div>
  </div>
</nav>
<div class="container d-flex justify-content-center align-items-start" style="padding-top:32px; padding-bottom:32px;">
<div class="app-card" style="width:100%; max-width:1000px;">
